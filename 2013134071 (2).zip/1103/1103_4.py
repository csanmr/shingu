color = ['red', 'blue', 'green']
color2 = ['ornage', 'black', 'white']
print color + color2
len(color)
color[0]='yellow'
print color*2
'blue' in color2
total_color = color+color2
for each_color in total_color:
    print each_color

