i=1
while i<10:
        print i
        i+=1


for i in range(0,5):
    print i

