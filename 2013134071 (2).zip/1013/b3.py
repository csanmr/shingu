for i in range(10):
    print i,
else:
    print "EOP"

i=0
while i<10:
    print i
    i+=1
else:
    print "EOP"
